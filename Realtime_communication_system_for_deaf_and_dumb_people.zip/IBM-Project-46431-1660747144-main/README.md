# IBM-Project-46431-1660747144
Real-Time Communication System Powered by AI for Specially Abled
